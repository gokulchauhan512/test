// Cloudinary is a FREE file storage service (no credit card required) that lets us
// upload PDFs and images directly from the browser and get back a public URL.
//
// SETUP (one-time, takes ~3 minutes):
// 1. Go to https://cloudinary.com/users/register/free and create a free account.
// 2. On your Cloudinary Dashboard, copy your "Cloud name" (top of the page).
// 3. Go to Settings (gear icon) -> Upload -> scroll to "Upload presets" -> "Add upload preset".
//    - Set "Signing Mode" to "Unsigned".
//    - Save, then copy the preset name it gives you.
// 4. Paste both values below.
//
// This is safe to keep in frontend code: an "unsigned" preset only allows uploads,
// never deletion or account access, and Cloudinary's free tier is generous
// (25 GB storage + 25 GB bandwidth/month) with no card needed.

export const CLOUDINARY_CLOUD_NAME = 'rapi9ahz';
export const CLOUDINARY_UPLOAD_PRESET = 'bteup.in';

export const CLOUDINARY_CONFIGURED = Boolean(
  CLOUDINARY_CLOUD_NAME.trim() && CLOUDINARY_UPLOAD_PRESET.trim()
);

export interface CloudinaryUploadResult {
  url: string;
  fileSizeLabel: string;
  resourceType: 'image' | 'raw' | 'video';
}

/**
 * Uploads a File (PDF or image) to Cloudinary and returns a public URL.
 * Uses Cloudinary's "auto" endpoint so it works for both images and PDFs (raw files).
 */
export async function uploadFileToCloudinary(file: File): Promise<CloudinaryUploadResult> {
  if (!CLOUDINARY_CONFIGURED) {
    throw new Error('Cloudinary is not configured yet. Add your Cloud name and upload preset in src/services/cloudinary.ts');
  }

  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);

  const endpoint = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/auto/upload`;

  const response = await fetch(endpoint, {
    method: 'POST',
    body: formData
  });

  if (!response.ok) {
    const errText = await response.text().catch(() => '');
    throw new Error(`Upload failed (${response.status}). ${errText || 'Please check your Cloudinary setup.'}`);
  }

  const data = await response.json();

  const kind = file.type.startsWith('image/') ? 'Image' : 'PDF';

  return {
    url: data.secure_url as string,
    fileSizeLabel: kind,
    resourceType: data.resource_type
  };
}
