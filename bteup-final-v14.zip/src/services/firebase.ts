import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { 
  getAuth, 
  Auth, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  User as FirebaseUser,
  updateProfile
} from 'firebase/auth';
import { 
  getFirestore, 
  Firestore, 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  getDoc,
  setDoc,
  getDocs, 
  query, 
  orderBy, 
  serverTimestamp,
  increment
} from 'firebase/firestore';
import { ResourceItem, UserProfile, NoteRequest } from '../types';
import { INITIAL_RESOURCES } from '../data/initialResources';
import { normalizeFormat } from '../utils/format';

// Kept out of plain text so it doesn't show up in casual "view source" searches.
// Real protection comes from Firestore security rules, not from hiding this.
export const ADMIN_EMAIL = String.fromCharCode(120,103,99,55,53,49,50,64,103,109,97,105,108,46,99,111,109);

export { normalizeFormat };

const firebaseConfig = {
  apiKey: "AIzaSyCiwCK7T6hL0a2w6Ree-QJ_Rq6ljfLm0iA",
  authDomain: "bteup-help.firebaseapp.com",
  projectId: "bteup-help",
  storageBucket: "bteup-help.firebasestorage.app",
  messagingSenderId: "251596218519",
  appId: "1:251596218519:web:28818011811b3f54d9c9d2"
};

let app: FirebaseApp | null = null;
let auth: Auth | null = null;
let db: Firestore | null = null;

try {
  if (!getApps().length) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApps()[0];
  }
  auth = getAuth(app);
  db = getFirestore(app);
} catch (err) {
  console.warn("Firebase initialization notice:", err);
}

export { app, auth, db };

// Local Storage Keys for fast caching & offline fallback
const LOCAL_RESOURCES_KEY = 'bteup_portal_resources_v2';
const LOCAL_USER_KEY = 'bteup_portal_user_v2';
const LOCAL_REQUESTS_KEY = 'bteup_portal_requests_v2';

// 1. Resources Management
export function getSavedResources(): ResourceItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_RESOURCES_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // An empty array is valid (admin deleted everything) - only seed when nothing was ever saved
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error("Failed to load local resources", e);
  }
  // Initialize with rich pre-seeded data
  localStorage.setItem(LOCAL_RESOURCES_KEY, JSON.stringify(INITIAL_RESOURCES));
  return INITIAL_RESOURCES;
}

export function saveLocalResources(resources: ResourceItem[]): void {
  try {
    localStorage.setItem(LOCAL_RESOURCES_KEY, JSON.stringify(resources));
  } catch (e) {
    console.error("Failed to save local resources", e);
  }
}

// Fetch resources from Firestore with fallback to LocalStorage.
// IMPORTANT: Once Firestore has data, it is treated as the single source of
// truth (not merged with this device's own stale local cache) - this is what
// makes deletes/edits done from one device correctly show up on every device.
export async function fetchAllResources(): Promise<ResourceItem[]> {
  const localList = getSavedResources();
  if (!db) return localList;

  try {
    const colRef = collection(db, 'bteup_resources');
    const q = query(colRef, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    
    if (!snapshot.empty) {
      const firestoreItems: ResourceItem[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        firestoreItems.push({
          id: docSnap.id,
          title: data.title || 'Untitled Document',
          description: data.description || '',
          category: data.category || 'Notes',
          branch: data.branch || 'ALL',
          semester: data.semester || 'All',
          subject: data.subject || 'General',
          url: data.url || '',
          type: data.type || 'pdf',
          fileSize: normalizeFormat(data.fileSize),
          academicYear: data.academicYear || '2026-27',
          downloadsCount: data.downloadsCount || 0,
          viewsCount: data.viewsCount || 0,
          uploadedBy: 'BTEUP Admin',
          createdAt: typeof data.createdAt === 'number' ? data.createdAt : Date.now(),
          isPinned: data.isPinned || false,
          tags: data.tags || []
        });
      });
      // Firestore is the source of truth now - overwrite local cache exactly
      // with what Firestore has, so deleted/edited items never reappear.
      saveLocalResources(firestoreItems);
      return firestoreItems;
    }
  } catch (err) {
    console.warn("Firestore fetch error, utilizing optimized local cache:", err);
    return localList;
  }
  // Firestore reachable but genuinely empty (nothing uploaded to cloud yet) -
  // show the local/seed list as a first-run fallback only.
  return localList;
}

// Firestore rejects `undefined` values - strip them before every write
function clean<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

export interface SyncResult {
  /** true only when the change really reached the cloud database (visible on every device) */
  synced: boolean;
}

// Upload/Add Resource
export async function uploadResource(
  resource: Omit<ResourceItem, 'id' | 'createdAt' | 'downloadsCount' | 'viewsCount'>
): Promise<ResourceItem & SyncResult> {
  const newItem: ResourceItem = {
    ...resource,
    id: 'res-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    downloadsCount: 0,
    viewsCount: 0,
    createdAt: Date.now()
  };

  // 1. Update local storage first for instant zero-latency UI response
  saveLocalResources([newItem, ...getSavedResources()]);

  // 2. Push to Firestore using the SAME id, so local cache and cloud always match
  //    (a later delete/edit then always hits the right cloud document).
  let synced = false;
  if (db) {
    try {
      await setDoc(doc(db, 'bteup_resources', newItem.id), clean(newItem));
      synced = true;
    } catch (e) {
      console.warn("Firestore save failed, saved locally only:", e);
    }
  }

  return { ...newItem, synced };
}

// Update existing resource
export async function updateResourceItem(id: string, updates: Partial<ResourceItem>): Promise<SyncResult> {
  const current = getSavedResources();
  const idx = current.findIndex(r => r.id === id);
  if (idx !== -1) {
    current[idx] = { ...current[idx], ...updates };
    saveLocalResources(current);
  }

  let synced = false;
  if (db) {
    try {
      // merge:true also works for the built-in sample items that don't exist in the cloud yet
      const base = idx !== -1 ? current[idx] : updates;
      await setDoc(doc(db, 'bteup_resources', id), clean(base), { merge: true });
      synced = true;
    } catch (e) {
      console.warn("Firestore update failed, updated locally only:", e);
    }
  }
  return { synced };
}

// Delete resource
export async function deleteResourceItem(id: string): Promise<SyncResult> {
  saveLocalResources(getSavedResources().filter(r => r.id !== id));

  let synced = false;
  if (db) {
    try {
      await deleteDoc(doc(db, 'bteup_resources', id));
      synced = true;
    } catch (e) {
      console.warn("Firestore delete failed, deleted locally only:", e);
    }
  }
  return { synced };
}

// Increment downloads count (without sign in!)
export function incrementDownloadCount(id: string): void {
  const current = getSavedResources();
  const idx = current.findIndex(r => r.id === id);
  if (idx !== -1) {
    current[idx].downloadsCount = (current[idx].downloadsCount || 0) + 1;
    saveLocalResources(current);
    if (db) {
      try {
        const docRef = doc(db, 'bteup_resources', id);
        updateDoc(docRef, { downloadsCount: increment(1) }).catch(() => {});
      } catch {
        // silent
      }
    }
  }
}

// Note Requests - saved in Firestore so the admin sees requests from every student/device
const REQUESTS_COLLECTION = 'bteup_requests';

export function getSavedRequests(): NoteRequest[] {
  try {
    const raw = localStorage.getItem(LOCAL_REQUESTS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export async function syncRequestsFromCloud(): Promise<void> {
  if (!db) return;
  try {
    const snap = await getDocs(collection(db, REQUESTS_COLLECTION));
    const list: NoteRequest[] = [];
    snap.forEach(d => {
      const x = d.data();
      list.push({
        id: d.id,
        studentName: x.studentName || '',
        studentEmail: x.studentEmail || '',
        branch: x.branch || 'CSE',
        semester: x.semester || '',
        subject: x.subject || '',
        details: x.details || '',
        status: x.status || 'pending',
        createdAt: typeof x.createdAt === 'number' ? x.createdAt : Date.now()
      });
    });
    list.sort((p, q) => q.createdAt - p.createdAt);
    localStorage.setItem(LOCAL_REQUESTS_KEY, JSON.stringify(list));
  } catch (e) {
    console.warn('Requests sync skipped (admin only):', e);
  }
}

export function submitNoteRequest(req: Omit<NoteRequest, 'id' | 'createdAt' | 'status'>): NoteRequest {
  const newReq: NoteRequest = {
    ...req,
    id: 'req-' + Date.now(),
    status: 'pending',
    createdAt: Date.now()
  };
  if (db) {
    setDoc(doc(db, REQUESTS_COLLECTION, newReq.id), newReq).catch(() => {});
  }
  return newReq;
}

export function updateRequestStatus(id: string, status: 'pending' | 'fulfilled' | 'in-progress'): void {
  const list = getSavedRequests().map(r => r.id === id ? { ...r, status } : r);
  localStorage.setItem(LOCAL_REQUESTS_KEY, JSON.stringify(list));
  if (db) {
    updateDoc(doc(db, REQUESTS_COLLECTION, id), { status }).catch(() => {});
  }
}

// 4. User Profiles (Firestore) - so full profile (name, branch, semester, college)
// is safely stored in the cloud, not just the browser's localStorage.
const USERS_COLLECTION = 'bteup_users';

export async function saveUserProfileToFirestore(profile: UserProfile): Promise<void> {
  if (!db || !profile.uid) return;
  try {
    const docRef = doc(db, USERS_COLLECTION, profile.uid);
    await setDoc(docRef, {
      uid: profile.uid,
      email: profile.email,
      displayName: profile.displayName,
      role: profile.role,
      branch: profile.branch || null,
      semester: profile.semester || null,
      college: profile.college || null,
      mobile: profile.mobile || null,
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (e) {
    console.warn('Firestore profile save skipped:', e);
  }
}

export async function fetchUserProfileFromFirestore(uid: string): Promise<Partial<UserProfile> | null> {
  if (!db || !uid) return null;
  try {
    const docRef = doc(db, USERS_COLLECTION, uid);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      const data = snap.data();
      return {
        displayName: data.displayName,
        branch: data.branch || undefined,
        semester: data.semester || undefined,
        college: data.college || undefined,
        mobile: data.mobile || undefined
      };
    }
  } catch (e) {
    console.warn('Firestore profile fetch skipped:', e);
  }
  return null;
}

// For Admin Panel: list all registered students
export async function fetchAllUserProfiles(): Promise<UserProfile[]> {
  if (!db) return [];
  try {
    const colRef = collection(db, USERS_COLLECTION);
    const snapshot = await getDocs(colRef);
    const list: UserProfile[] = [];
    snapshot.forEach(docSnap => {
      const data = docSnap.data();
      list.push({
        uid: data.uid || docSnap.id,
        email: data.email || '',
        displayName: data.displayName || '',
        role: data.role || 'student',
        branch: data.branch || undefined,
        semester: data.semester || undefined,
        college: data.college || undefined,
        mobile: data.mobile || undefined,
        bookmarks: []
      });
    });
    return list;
  } catch (e) {
    console.warn('Firestore user list fetch skipped:', e);
    return [];
  }
}

// 5. All-time Visitor Counter (public, shown to everyone in the footer)
// Stored in Firestore at bteup_meta/site_stats so the same number is visible
// on every device/phone. Counts once per browser tab session (not every
// page reload/navigation) using sessionStorage as a simple de-dupe guard.
const SITE_STATS_COLLECTION = 'bteup_meta';
const SITE_STATS_DOC = 'site_stats';
const VISIT_SESSION_FLAG = 'bteup_visit_counted_v1';
const LOCAL_VISITOR_CACHE_KEY = 'bteup_visitor_count_cache_v1';

export async function registerVisitAndGetCount(): Promise<number> {
  const readCache = (): number => {
    try {
      const cached = localStorage.getItem(LOCAL_VISITOR_CACHE_KEY);
      const n = cached ? parseInt(cached, 10) : 0;
      return Number.isFinite(n) ? n : 0;
    } catch {
      return 0;
    }
  };

  if (!db) return readCache();

  const docRef = doc(db, SITE_STATS_COLLECTION, SITE_STATS_DOC);
  let alreadyCountedThisTab: string | null = null;
  try { alreadyCountedThisTab = sessionStorage.getItem(VISIT_SESSION_FLAG); } catch {}

  try {
    if (!alreadyCountedThisTab) {
      // increment() safely creates the field (starting at 0) if it doesn't
      // exist yet, so this works even on the very first visitor.
      await setDoc(docRef, { totalVisits: increment(1) }, { merge: true });
      try { sessionStorage.setItem(VISIT_SESSION_FLAG, '1'); } catch {}
    }
    const snap = await getDoc(docRef);
    const count = snap.exists() ? (snap.data().totalVisits || 0) : 0;
    try { localStorage.setItem(LOCAL_VISITOR_CACHE_KEY, String(count)); } catch {}
    return count;
  } catch (e) {
    console.warn('Visitor counter skipped:', e);
    return readCache();
  }
}


// 6. Home page "Latest Notice" ticker - editable from the Admin Panel.
// Stored in Firestore at bteup_meta/home_notice (public read, admin-only write).
export interface HomeNotice {
  title: string;
  date: string;
  link: string;
  visible: boolean;
}

const HOME_NOTICE_DOC = 'home_notice';
const LOCAL_NOTICE_KEY = 'bteup_home_notice_v1';

export function getDefaultHomeNotice(): HomeNotice {
  // No made-up announcement: the bar stays hidden until the admin writes a real notice
  return { title: '', date: '', link: '', visible: true };
}

export function getCachedHomeNotice(): HomeNotice {
  try {
    const raw = localStorage.getItem(LOCAL_NOTICE_KEY);
    if (raw) {
      const p = JSON.parse(raw);
      if (p && typeof p.title === 'string') return { ...getDefaultHomeNotice(), ...p };
    }
  } catch {}
  return getDefaultHomeNotice();
}

export async function fetchHomeNotice(): Promise<HomeNotice> {
  const cached = getCachedHomeNotice();
  if (!db) return cached;
  try {
    const snap = await getDoc(doc(db, SITE_STATS_COLLECTION, HOME_NOTICE_DOC));
    if (snap.exists()) {
      const d = snap.data();
      const notice: HomeNotice = {
        title: String(d.title ?? ''),
        date: String(d.date ?? ''),
        link: String(d.link ?? ''),
        visible: d.visible !== false
      };
      try { localStorage.setItem(LOCAL_NOTICE_KEY, JSON.stringify(notice)); } catch {}
      return notice;
    }
  } catch (e) {
    console.warn('Home notice fetch skipped:', e);
  }
  return cached;
}

export async function saveHomeNotice(notice: HomeNotice): Promise<SyncResult> {
  try { localStorage.setItem(LOCAL_NOTICE_KEY, JSON.stringify(notice)); } catch {}
  if (!db) return { synced: false };
  try {
    await setDoc(doc(db, SITE_STATS_COLLECTION, HOME_NOTICE_DOC), clean({ ...notice, updatedAt: Date.now() }));
    return { synced: true };
  } catch (e) {
    console.warn('Home notice save failed:', e);
    return { synced: false };
  }
}
