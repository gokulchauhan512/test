import React, { useState, useEffect, useRef } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { BranchSelector } from './components/BranchSelector';
import { ResourceCatalog } from './components/ResourceCatalog';
import { ImportantLinksSection } from './components/ImportantLinksSection';
import { ResourcePreviewModal } from './components/ResourcePreviewModal';
import { AdminPanel } from './components/AdminPanel';
import { AuthModal } from './components/AuthModal';
import { RequestNoteModal } from './components/RequestNoteModal';
import { Footer } from './components/Footer';
import { ResourceItem, BranchCode, ResourceCategory } from './types';
import { 
  getSavedResources, 
  fetchAllResources, 
  incrementDownloadCount,
  deleteResourceItem,
  registerVisitAndGetCount
} from './services/firebase';
import { getDriveDownloadUrl } from './utils/driveHelper';
import { Download } from 'lucide-react';

function AppContent() {
  const { user, isAdmin, bookmarks } = useAuth();

  // Core Data State
  const [resources, setResources] = useState<ResourceItem[]>(() => getSavedResources());
  const [selectedBranch, setSelectedBranch] = useState<BranchCode>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<ResourceCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeView, setActiveView] = useState<string>('home');
  const [showBookmarksOnly, setShowBookmarksOnly] = useState<boolean>(false);

  // Modals
  const [previewResource, setPreviewResource] = useState<ResourceItem | null>(null);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState<boolean>(false);
  const [authModalState, setAuthModalState] = useState<{ isOpen: boolean; mode: 'login' | 'register' }>({
    isOpen: false,
    mode: 'login'
  });
  const [isRequestModalOpen, setIsRequestModalOpen] = useState<boolean>(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // All-time visitor counter (public, shown in footer)
  const [visitorCount, setVisitorCount] = useState<number>(0);

  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  // Synchronize Firestore resources on startup, and again whenever the visitor returns to the tab
  // (so edits/deletes made by the admin on another device show up without a manual reload)
  useEffect(() => {
    let lastSync = 0;
    const sync = () => {
      lastSync = Date.now();
      fetchAllResources()
        .then(items => { if (Array.isArray(items)) setResources(items); })
        .catch(() => {});
    };
    sync();
    const onVisible = () => {
      if (document.visibilityState === 'visible' && Date.now() - lastSync > 60000) sync();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, []);

  // Register this visit & load the public all-time visitor count
  useEffect(() => {
    registerVisitAndGetCount().then(count => {
      setVisitorCount(count);
    });
  }, []);

  const refreshResourcesList = () => {
    setResources(getSavedResources());
  };

  // Direct Download Handler (NO sign-in required!)
  const handleDownload = (resource: ResourceItem) => {
    // 1. Increment stats
    incrementDownloadCount(resource.id);
    refreshResourcesList();

    // 2. Generate direct Google Drive download link
    const downloadUrl = getDriveDownloadUrl(resource.url);

    // 3. Inform user
    showToast(`Downloading "${resource.title}" from Google Drive...`);

    // 4. Open direct download in new window/tab
    window.open(downloadUrl, '_blank', 'noopener,noreferrer');
  };

  const handleBranchSelect = (branch: BranchCode) => {
    setSelectedBranch(branch);
    setShowBookmarksOnly(false);
    setActiveView('resources');
    const el = document.getElementById('resources-catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleCategorySelect = (cat: ResourceCategory | 'All') => {
    setSelectedCategory(cat);
    setShowBookmarksOnly(false);
    setActiveView('resources');
    const el = document.getElementById('resources-catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleOpenBookmarks = () => {
    setShowBookmarksOnly(true);
    setActiveView('resources');
    const el = document.getElementById('resources-catalog');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleDeleteResource = async (id: string) => {
    const { synced } = await deleteResourceItem(id);
    refreshResourcesList();
    showToast(synced
      ? 'Resource removed successfully.'
      : 'Removed on this device only - cloud sync failed (check admin login / Firestore rules).');
  };

  return (
    <div className="min-h-screen flex flex-col text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Toast Notification Container */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200">
          <div className="flex items-center gap-3 bg-slate-900 text-white dark:bg-white dark:text-slate-900 px-5 py-3.5 rounded-2xl shadow-2xl border border-slate-700/50 text-xs sm:text-sm font-bold">
            <Download className="w-4 h-4 text-emerald-400 dark:text-emerald-600 animate-bounce" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Top Navigation Bar */}
      <Navbar
        onSelectCategory={handleCategorySelect}
        onSelectBranch={handleBranchSelect}
        onOpenAuth={(mode = 'login') => setAuthModalState({ isOpen: true, mode })}
        onOpenAdminPanel={() => setIsAdminPanelOpen(true)}
        onOpenBookmarks={handleOpenBookmarks}
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Main Content Sections */}
      <main className="flex-grow">
        
        {/* Hero Section with Notice ticker and Instant Search */}
        <HeroBanner
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onSelectCategory={handleCategorySelect}
          onSelectBranch={handleBranchSelect}
          onSearchSubmit={() => {
            setShowBookmarksOnly(false);
            setActiveView('resources');
            const el = document.getElementById('resources-catalog');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
          totalResourcesCount={resources.length}
        />

        {/* Branch Selection Cards */}
        <BranchSelector
          selectedBranch={selectedBranch}
          onSelectBranch={handleBranchSelect}
          resources={resources}
        />

        {/* Digital Resource Catalog (Syllabus, Notes, Papers) */}
        <ResourceCatalog
          resources={resources}
          selectedBranch={selectedBranch}
          setSelectedBranch={(b) => { setSelectedBranch(b); setShowBookmarksOnly(false); }}
          selectedCategory={selectedCategory}
          setSelectedCategory={(c) => { setSelectedCategory(c); setShowBookmarksOnly(false); }}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onPreview={(res) => setPreviewResource(res)}
          onDownload={handleDownload}
          onDeleteResource={handleDeleteResource}
          onOpenRequestModal={() => setIsRequestModalOpen(true)}
          onlyBookmarked={showBookmarksOnly}
          bookmarkedIds={bookmarks}
        />

        {/* Official Examination & UP Portals Links Section */}
        <ImportantLinksSection />

      </main>

      {/* Footer with Mandatory BTEUP Unofficial Disclaimer */}
      <Footer
        onSelectBranch={handleBranchSelect}
        onOpenRequestModal={() => setIsRequestModalOpen(true)}
        visitorCount={visitorCount}
      />

      {/* Preview Modal for Google Drive / PDF Embed */}
      <ResourcePreviewModal
        resource={previewResource}
        onClose={() => setPreviewResource(null)}
        onDownload={handleDownload}
      />

      {/* Admin Panel Modal */}
      {isAdminPanelOpen && (
        <AdminPanel
          resources={resources}
          onRefreshResources={refreshResourcesList}
          onClose={() => setIsAdminPanelOpen(false)}
        />
      )}

      {/* Student & Admin Auth Modal */}
      <AuthModal
        isOpen={authModalState.isOpen}
        onClose={() => setAuthModalState({ isOpen: false, mode: 'login' })}
        initialMode={authModalState.mode}
      />

      {/* Student Request Note Modal */}
      <RequestNoteModal
        isOpen={isRequestModalOpen}
        onClose={() => setIsRequestModalOpen(false)}
      />

    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}
