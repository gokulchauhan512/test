export type BranchCode = 'ALL' | 'CSE' | 'ME' | 'CE' | 'EE' | 'EEE';

export interface BranchInfo {
  code: BranchCode;
  name: string;
  shortName: string;
  fullName: string;
  iconName: string;
  color: string;
  description: string;
}

export type ResourceCategory = 'Syllabus' | 'Notes' | 'Paper' | 'Link' | 'ModelPaper';

export interface ResourceItem {
  id: string;
  title: string;
  description: string;
  category: ResourceCategory;
  branch: BranchCode;
  semester: string; // "1", "2", "3", "4", "5", "6", or "All"
  subject: string;
  url: string;
  type: 'pdf' | 'link' | 'drive';
  fileSize?: string;
  academicYear?: string;
  downloadsCount: number;
  viewsCount: number;
  uploadedBy: string;
  createdAt: number;
  isPinned?: boolean;
  tags?: string[];
}

export interface NoticeItem {
  id: string;
  title: string;
  date: string;
  isNew?: boolean;
  isUrgent?: boolean;
  link?: string;
  category: 'exam' | 'result' | 'admitCard' | 'general' | 'circular';
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: 'admin' | 'student';
  branch?: BranchCode;
  semester?: string;
  college?: string;
  mobile?: string;
  bookmarks: string[];
}

export interface NoteRequest {
  id: string;
  studentName: string;
  studentEmail: string;
  branch: BranchCode;
  semester: string;
  subject: string;
  details: string;
  status: 'pending' | 'fulfilled' | 'in-progress';
  createdAt: number;
}
