import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { enableSiteProtection } from './utils/protect';
import { enableTilt } from './utils/tilt';

enableSiteProtection();
enableTilt();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
