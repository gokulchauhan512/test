/**
 * Utility functions to process Google Drive / Cloudinary URLs for direct downloading and in-app preview
 */

// Only plain http(s) links are ever opened or embedded (blocks javascript:, data: etc.)
export function safeHttpUrl(raw: string): string {
  const u = (raw || '').trim();
  return /^https?:\/\//i.test(u) ? u : '';
}

export function extractDriveId(rawUrl: string): string | null {
  if (!rawUrl) return null;
  const url = rawUrl.trim();

  // Pattern 1: /file/d/{id}
  const fileDMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileDMatch && fileDMatch[1]) return fileDMatch[1];

  // Pattern 2: id={id}
  const idQueryMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idQueryMatch && idQueryMatch[1]) return idQueryMatch[1];

  // Pattern 3: /document/d/{id} or /spreadsheets/d/{id} or /presentation/d/{id}
  const docMatch = url.match(/\/(?:document|spreadsheets|presentation)\/d\/([a-zA-Z0-9_-]+)/);
  if (docMatch && docMatch[1]) return docMatch[1];

  // Pattern 4: /folders/{id}
  const folderMatch = url.match(/\/folders\/([a-zA-Z0-9_-]+)/);
  if (folderMatch && folderMatch[1]) return folderMatch[1];

  return null;
}

export function isDriveUrl(url: string): boolean {
  if (!url) return false;
  return url.includes('drive.google.com') || url.includes('docs.google.com');
}

export function isDriveFolder(url: string): boolean {
  return /\/folders\/[a-zA-Z0-9_-]+/.test(url || '');
}

export function isCloudinaryUrl(url: string): boolean {
  return /^https?:\/\/res\.cloudinary\.com\//i.test(url || '') && (url || '').includes('/upload/');
}

export function getDrivePreviewUrl(url: string): string {
  const clean = safeHttpUrl(url);
  if (!clean) return 'about:blank';
  const fileId = extractDriveId(clean);
  if (fileId && isDriveFolder(clean)) {
    // Folders cannot be shown with the /preview file viewer
    return `https://drive.google.com/embeddedfolderview?id=${fileId}#list`;
  }
  if (fileId) return `https://drive.google.com/file/d/${fileId}/preview`;
  return clean;
}

export function getDriveDownloadUrl(url: string): string {
  const clean = safeHttpUrl(url);
  if (!clean) return '#';
  const fileId = extractDriveId(clean);
  if (fileId && isDriveFolder(clean)) {
    // A folder cannot be downloaded as a single file - open the folder itself
    return `https://drive.google.com/drive/folders/${fileId}`;
  }
  if (fileId) return `https://drive.google.com/uc?export=download&id=${fileId}`;
  if (isCloudinaryUrl(clean) && !clean.includes('/fl_attachment')) {
    // Ask Cloudinary to send the file as a download instead of opening it inline
    return clean.replace('/upload/', '/upload/fl_attachment/');
  }
  return clean;
}

export function getCleanViewUrl(url: string): string {
  const clean = safeHttpUrl(url);
  if (!clean) return '#';
  const fileId = extractDriveId(clean);
  if (fileId && isDriveFolder(clean)) return `https://drive.google.com/drive/folders/${fileId}`;
  if (fileId) return `https://drive.google.com/file/d/${fileId}/view`;
  return clean;
}
