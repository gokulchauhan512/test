// Normalise any legacy size/format text (e.g. "PDF 4.5 MB") to just PDF / Image / Drive Folder.
export function normalizeFormat(v?: string): string {
  const t = (v || '').toLowerCase();
  if (/image|img|png|jpe?g|webp/.test(t)) return 'Image';
  if (/folder/.test(t)) return 'Drive Folder';
  return 'PDF';
}
