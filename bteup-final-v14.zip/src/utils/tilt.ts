// Gentle 3D tilt for any element with the "tilt-3d" class.
// Mouse / trackpad only - disabled on touch screens and for users who prefer reduced motion.
export function enableTilt(): void {
  if (typeof window === 'undefined' || !window.matchMedia) return;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!finePointer || reduceMotion) return;

  const MAX_DEG = 3;
  let current: HTMLElement | null = null;
  let frame = 0;

  const reset = (el: HTMLElement | null) => {
    if (!el) return;
    el.style.setProperty('--rx', '0deg');
    el.style.setProperty('--ry', '0deg');
    el.classList.remove('is-tilting');
  };

  document.addEventListener('pointermove', (e: PointerEvent) => {
    const target = (e.target as Element | null)?.closest?.('.tilt-3d') as HTMLElement | null;
    if (target !== current) {
      reset(current);
      current = target;
    }
    if (!current || frame) return;
    const x = e.clientX;
    const y = e.clientY;
    frame = requestAnimationFrame(() => {
      frame = 0;
      if (!current) return;
      const r = current.getBoundingClientRect();
      const px = (x - r.left) / r.width - 0.5;
      const py = (y - r.top) / r.height - 0.5;
      current.classList.add('is-tilting');
      current.style.setProperty('--ry', `${(px * MAX_DEG * 2).toFixed(2)}deg`);
      current.style.setProperty('--rx', `${(-py * MAX_DEG * 2).toFixed(2)}deg`);
    });
  }, { passive: true });

  const clear = () => { reset(current); current = null; };
  document.addEventListener('pointerout', (e: PointerEvent) => { if (!e.relatedTarget) clear(); });
  window.addEventListener('blur', clear);
}
