// Light-weight deterrent: blocks right-click and the common "view source / inspect" shortcuts.
// NOTE: this only discourages casual visitors. Real data protection comes from the
// Firestore security rules, which are enforced on the server and cannot be bypassed from the browser.
export function enableSiteProtection(): void {
  if (typeof window === 'undefined') return;

  const isFormField = (t: EventTarget | null) => {
    const el = t as HTMLElement | null;
    return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA');
  };

  document.addEventListener('contextmenu', (e) => {
    if (isFormField(e.target)) return; // keep paste/copy menu usable in form fields
    e.preventDefault();
  });

  document.addEventListener('dragstart', (e) => {
    if ((e.target as HTMLElement)?.tagName === 'IMG') e.preventDefault();
  });

  document.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    const ctrl = e.ctrlKey || e.metaKey;
    const blocked =
      k === 'f12' ||
      (ctrl && e.shiftKey && ['i', 'j', 'c', 'k'].includes(k)) ||
      (ctrl && ['u', 's'].includes(k)) ||
      (e.metaKey && e.altKey && ['i', 'j', 'c', 'u'].includes(k));
    if (blocked) e.preventDefault();
  });
}
