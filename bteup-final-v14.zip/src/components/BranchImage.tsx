import React, { useState } from 'react';

// Put a picture for each branch in  public/images/branches/<code>.jpg  (also .webp / .png work):
//   all, cse, me, ce, ee, eee
// Without your file, a built-in illustration (.svg) is shown; if that is missing too, the icon is used.
const EXTENSIONS = ['webp', 'jpg', 'png', 'svg'];

interface BranchImageProps {
  code: string;
  alt: string;
  fallback: React.ReactNode;
}

export const BranchImage: React.FC<BranchImageProps> = ({ code, alt, fallback }) => {
  const [idx, setIdx] = useState(0);

  if (idx >= EXTENSIONS.length) {
    return <div className="h-36 sm:h-40 flex items-center justify-center">{fallback}</div>;
  }

  return (
    <img
      src={`/images/branches/${code.toLowerCase()}.${EXTENSIONS[idx]}`}
      alt={alt}
      loading="lazy"
      onError={() => setIdx(idx + 1)}
      className="w-full h-36 sm:h-40 object-cover rounded-lg"
      draggable={false}
    />
  );
};
