import React, { useEffect } from 'react';
import { 
  X, 
  Download, 
  ExternalLink, 
  FileText, 
  HardDrive, 
  Calendar, 
  AlertCircle,
  Share2
} from 'lucide-react';
import { ResourceItem } from '../types';
import { getDrivePreviewUrl, getDriveDownloadUrl, getCleanViewUrl, isDriveUrl, isDriveFolder } from '../utils/driveHelper';
import { normalizeFormat } from '../utils/format';

interface ResourcePreviewModalProps {
  resource: ResourceItem | null;
  onClose: () => void;
  onDownload: (resource: ResourceItem) => void;
}

export const ResourcePreviewModal: React.FC<ResourcePreviewModalProps> = ({
  resource,
  onClose,
  onDownload
}) => {
  // Close with the Escape key
  useEffect(() => {
    if (!resource) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [resource, onClose]);

  if (!resource) return null;

  const fromDrive = isDriveUrl(resource.url);
  const isFolder = isDriveFolder(resource.url);
  const previewUrl = getDrivePreviewUrl(resource.url);
  const directDownloadUrl = getDriveDownloadUrl(resource.url);
  const driveViewUrl = getCleanViewUrl(resource.url);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(resource.url);
      alert("Resource link copied to clipboard!");
    } catch {
      window.prompt('Copy this link:', resource.url);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="preview-modal-container"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-5xl h-[90vh] flex flex-col shadow-2xl overflow-hidden"
      >
        
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 shrink-0 bg-slate-50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="truncate">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white truncate">
                {resource.title}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-medium">
                <span>{resource.subject}</span>
                <span>•</span>
                <span>{resource.branch} (Sem {resource.semester})</span>
                {resource.fileSize && (
                  <>
                    <span>•</span>
                    <span>{normalizeFormat(resource.fileSize)}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleCopyLink}
              title="Share Link"
              className="p-2 rounded-xl text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800 transition"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              id="modal-download-btn"
              onClick={() => onDownload(resource)}
              className="flex items-center gap-1.5 px-3 sm:px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-sm transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{isFolder ? 'Open Folder' : 'Download'}</span>
            </button>

            <button
              id="modal-close-btn"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Google Drive Embedded Preview */}
        <div className="flex-1 relative bg-slate-100 dark:bg-slate-950 overflow-hidden flex flex-col">
          <iframe
            src={previewUrl}
            title={resource.title}
            className="w-full h-full border-0"
            allow="autoplay"
          />

          {/* Fallback Notice Bar at the bottom */}
          <div className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
              <AlertCircle className="w-4 h-4 text-blue-500 shrink-0" />
              <span>{fromDrive ? 'If preview does not load due to Google Drive permissions, click Open or Download below:' : 'If the preview does not load, use the Open or Download links:'}</span>
            </div>

            <div className="flex items-center gap-2">
              <a
                href={driveViewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 font-bold hover:underline"
              >
                <span>{fromDrive ? 'Open in Google Drive' : 'Open original'}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <a
                href={directDownloadUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 px-3 py-1 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold rounded-lg hover:bg-slate-300 dark:hover:bg-slate-700 transition"
              >
                <span>{isFolder ? 'Folder Link' : 'Direct File Link'}</span>
              </a>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
