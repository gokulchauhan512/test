import { BrandLogo } from './BrandLogo';
import React, { useState } from 'react';
import { 
  GraduationCap, 
  Moon, 
  Sun, 
  User, 
  ShieldCheck, 
  LogOut, 
  Menu, 
  X, 
  BookOpen, 
  FileText, 
  FolderDown, 
  ExternalLink,
  Search,
  Bookmark
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { BranchCode, ResourceCategory } from '../types';

interface NavbarProps {
  onSelectCategory: (category: ResourceCategory | 'All') => void;
  onSelectBranch: (branch: BranchCode) => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onOpenAdminPanel: () => void;
  onOpenBookmarks: () => void;
  activeView: string;
  setActiveView: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onSelectCategory,
  onSelectBranch,
  onOpenAuth,
  onOpenAdminPanel,
  onOpenBookmarks,
  activeView,
  setActiveView
}) => {
  const { theme, toggleTheme } = useTheme();
  const { user, isAdmin, logout, bookmarks } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [branchDropdownOpen, setBranchDropdownOpen] = useState(false);

  const branches: { code: BranchCode; label: string }[] = [
    { code: 'ALL', label: '1st Year Common' },
    { code: 'CSE', label: 'Computer Science (CSE)' },
    { code: 'ME', label: 'Mechanical Engg. (ME)' },
    { code: 'CE', label: 'Civil Engg. (CE)' },
    { code: 'EE', label: 'Electrical Engg. (EE)' },
    { code: 'EEE', label: 'Electrical & Electronics (EEE)' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full neu-bar transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo */}
          <div 
            id="nav-logo" 
            onClick={() => { setActiveView('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="group-hover:scale-105 transition-transform duration-200">
              <BrandLogo />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">BTE<span className="text-blue-600 dark:text-blue-400">UP</span></span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">Vault</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium -mt-1 hidden sm:block">Polytechnic Diploma Study Portal</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2 text-sm font-semibold">
            <button
              id="nav-home-btn"
              onClick={() => { setActiveView('home'); }}
              className={`px-3 py-2 rounded-lg transition-colors ${
                activeView === 'home'
                  ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 font-bold'
                  : 'text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              Home
            </button>

            {/* Branches Dropdown */}
            <div className="relative">
              <button
                id="nav-branches-dropdown-btn"
                onClick={() => setBranchDropdownOpen(!branchDropdownOpen)}
                onMouseEnter={() => setBranchDropdownOpen(true)}
                className="px-3 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1"
              >
                <span>Branches</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {branchDropdownOpen && (
                <div 
                  className="absolute left-0 mt-1 w-64 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                  onMouseLeave={() => setBranchDropdownOpen(false)}
                >
                  <div className="px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-slate-400">Select Engineering Branch</div>
                  {branches.map(b => (
                    <button
                      key={b.code}
                      onClick={() => {
                        onSelectBranch(b.code);
                        setActiveView('resources');
                        setBranchDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-sm text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950/60 hover:text-blue-600 dark:hover:text-blue-400 font-medium transition-colors flex items-center justify-between"
                    >
                      <span>{b.label}</span>
                      <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400">{b.code}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              id="nav-syllabus-btn"
              onClick={() => { onSelectCategory('Syllabus'); setActiveView('resources'); }}
              className="px-3 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Syllabus
            </button>

            <button
              id="nav-notes-btn"
              onClick={() => { onSelectCategory('Notes'); setActiveView('resources'); }}
              className="px-3 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Notes & PDF
            </button>

            <button
              id="nav-papers-btn"
              onClick={() => { onSelectCategory('Paper'); setActiveView('resources'); }}
              className="px-3 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Question Papers (PYQ)
            </button>

            <button
              id="nav-links-btn"
              onClick={() => {
                const el = document.getElementById('official-links-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
                else setActiveView('home');
              }}
              className="px-3 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              Official Links
            </button>
          </nav>

          {/* Right Action Icons & Auth */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Bookmarks Counter Button */}
            {bookmarks.length > 0 && (
              <button
                id="nav-bookmarks-btn"
                onClick={onOpenBookmarks}
                title="Saved Bookmarks"
                className="relative p-2.5 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Bookmark className="w-5 h-5 fill-amber-400 text-amber-500" />
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-[11px] font-bold rounded-full flex items-center justify-center">
                  {bookmarks.length}
                </span>
              </button>
            )}

            {/* Dark Mode Toggle */}
            <button
              id="theme-toggle-btn"
              onClick={toggleTheme}
              aria-label="Toggle Dark Mode"
              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-slate-600" />}
            </button>

            {/* Auth Buttons / User Profile */}
            {user ? (
              <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
                {isAdmin && (
                  <button
                    id="nav-admin-dashboard-btn"
                    onClick={onOpenAdminPanel}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold hover:bg-slate-800 dark:hover:bg-slate-100 shadow-sm transition-all"
                  >
                    <ShieldCheck className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
                    <span>Admin Panel</span>
                  </button>
                )}

                <div className="hidden sm:flex flex-col text-right">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 leading-tight">
                    {user.displayName}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400">
                    {isAdmin ? 'Administrator' : (user.branch || 'Student')}
                  </span>
                </div>

                <button
                  id="nav-logout-btn"
                  onClick={logout}
                  title="Logout"
                  className="p-2.5 rounded-xl text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="nav-login-btn"
                  onClick={() => onOpenAuth('login')}
                  className="px-3.5 py-2 text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 transition"
                >
                  <span className="sm:hidden">Login</span>
                  <span className="hidden sm:inline">Student Login</span>
                </button>
                <button
                  id="nav-register-btn"
                  onClick={() => onOpenAuth('register')}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-bold shadow-md shadow-blue-500/20 transition-transform active:scale-95"
                >
                  Register
                </button>
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Open Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              onClick={() => { setActiveView('home'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg text-left bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              Home
            </button>
            <button
              onClick={() => { onSelectCategory('Syllabus'); setActiveView('resources'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg text-left bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              Syllabus
            </button>
            <button
              onClick={() => { onSelectCategory('Notes'); setActiveView('resources'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg text-left bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              Notes & PDFs
            </button>
            <button
              onClick={() => { onSelectCategory('Paper'); setActiveView('resources'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-lg text-left bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
            >
              PYQ Papers
            </button>
          </div>

          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Branches</div>
            <div className="grid grid-cols-2 gap-2">
              {branches.map(b => (
                <button
                  key={b.code}
                  onClick={() => {
                    onSelectBranch(b.code);
                    setActiveView('resources');
                    setMobileMenuOpen(false);
                  }}
                  className="text-left px-3 py-2 rounded-lg text-xs font-medium bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:text-blue-600"
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>

          {isAdmin && (
            <button
              onClick={() => { onOpenAdminPanel(); setMobileMenuOpen(false); }}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-sm flex items-center justify-center gap-2 shadow"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
              Open Admin Control Panel
            </button>
          )}
        </div>
      )}
    </header>
  );
};
