import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  Upload, 
  FileText, 
  Trash2, 
  Edit3, 
  CheckCircle, 
  AlertCircle, 
  Link as LinkIcon, 
  Layers, 
  Search, 
  HardDrive, 
  Clock, 
  X,
  MessageSquare,
  ShieldCheck,
  ArrowRight,
  Pin,
  Bell
} from 'lucide-react';
import { ResourceItem, BranchCode, ResourceCategory, NoteRequest } from '../types';
import { 
  uploadResource, 
  updateResourceItem, 
  deleteResourceItem, 
  getSavedRequests, 
  updateRequestStatus,
  syncRequestsFromCloud,
  fetchHomeNotice,
  saveHomeNotice,
  getDefaultHomeNotice,
  HomeNotice
} from '../services/firebase';
import { extractDriveId, isDriveUrl, safeHttpUrl } from '../utils/driveHelper';
import { uploadFileToCloudinary, CLOUDINARY_CONFIGURED } from '../services/cloudinary';

interface AdminPanelProps {
  resources: ResourceItem[];
  onRefreshResources: () => void;
  onClose: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  resources,
  onRefreshResources,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'manage' | 'requests' | 'notice'>('upload');
  
  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ResourceCategory>('Notes');
  const [branch, setBranch] = useState<BranchCode>('CSE');
  const [semester, setSemester] = useState('3');
  const [subject, setSubject] = useState('');
  const [url, setUrl] = useState('');
  const [academicYear, setAcademicYear] = useState('2026-27');
  const [fileSize, setFileSize] = useState('PDF');
  const [isPinned, setIsPinned] = useState(false);
  const [tagsInput, setTagsInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Upload source mode: paste a link, or upload a PDF/Image file directly (via Cloudinary)
  const [sourceMode, setSourceMode] = useState<'link' | 'file'>('link');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isFileUploading, setIsFileUploading] = useState(false);
  const [fileUploadProgress, setFileUploadProgress] = useState<string | null>(null);

  // Manage Tab search
  const [manageSearch, setManageSearch] = useState('');
  const [requests, setRequests] = useState<NoteRequest[]>(() => getSavedRequests());
  useEffect(() => {
    syncRequestsFromCloud().then(() => setRequests(getSavedRequests()));
  }, []);

  // Home page notice editor
  const todayLabel = () => new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  const [notice, setNotice] = useState<HomeNotice>(() => getDefaultHomeNotice());
  const [noticeSaving, setNoticeSaving] = useState(false);
  useEffect(() => {
    fetchHomeNotice().then(n => setNotice(n)).catch(() => {});
  }, []);

  const handleSaveNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (notice.visible && !notice.title.trim()) {
      setMessage({ type: 'error', text: 'Please type the notice text (or untick "Show notice on homepage").' });
      return;
    }
    if (notice.link.trim() && !safeHttpUrl(notice.link)) {
      setMessage({ type: 'error', text: 'The notice link must start with http:// or https://' });
      return;
    }
    setNoticeSaving(true);
    const { synced } = await saveHomeNotice({
      title: notice.title.trim(),
      date: notice.date.trim(),
      link: notice.link.trim(),
      visible: notice.visible
    });
    setNoticeSaving(false);
    setMessage(synced
      ? { type: 'success', text: 'Homepage notice updated for all visitors!' }
      : { type: 'error', text: 'Saved on this device only - the cloud database rejected it. Make sure you are logged in as admin and the Firestore rules are published.' });
  };

  // Drive detection
  const detectedDriveId = extractDriveId(url);

  const resetForm = () => {
    setEditingId(null);
    setTitle('');
    setDescription('');
    setCategory('Notes');
    setBranch('CSE');
    setSemester('3');
    setSubject('');
    setUrl('');
    setAcademicYear('2026-27');
    setFileSize('PDF');
    setIsPinned(false);
    setTagsInput('');
    setSourceMode('link');
    setSelectedFile(null);
    setFileUploadProgress(null);
  };

  const handleEditClick = (res: ResourceItem) => {
    setEditingId(res.id);
    setTitle(res.title);
    setDescription(res.description);
    setCategory(res.category);
    setBranch(res.branch);
    setSemester(res.semester);
    setSubject(res.subject);
    setUrl(res.url);
    setAcademicYear(res.academicYear || '2026-27');
    setFileSize(/image|img|png|jpe?g|webp/i.test(res.fileSize || '') ? 'Image' : 'PDF');
    setIsPinned(Boolean(res.isPinned));
    setTagsInput((res.tags || []).join(', '));
    setSourceMode('link');
    setSelectedFile(null);
    setActiveTab('upload');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      setMessage({ type: 'error', text: 'Please enter a Title.' });
      return;
    }

    if (sourceMode === 'link' && !url.trim()) {
      setMessage({ type: 'error', text: 'Please enter a Google Drive link or file URL.' });
      return;
    }

    if (sourceMode === 'link' && !safeHttpUrl(url)) {
      setMessage({ type: 'error', text: 'The link must start with http:// or https://' });
      return;
    }

    if (sourceMode === 'file' && !selectedFile) {
      setMessage({ type: 'error', text: 'Please choose a PDF or Image file to upload.' });
      return;
    }

    setIsSubmitting(true);
    setMessage(null);

    let finalUrl = sourceMode === 'link' ? url.trim() : '';
    let finalFileSize = fileSize;

    // If uploading a real file, push it to Cloudinary first to get a public URL
    if (sourceMode === 'file' && selectedFile) {
      if (!CLOUDINARY_CONFIGURED) {
        setMessage({ type: 'error', text: 'File upload storage is not configured yet. Please use a Link instead, or ask to finish Cloudinary setup.' });
        setIsSubmitting(false);
        return;
      }
      try {
        setIsFileUploading(true);
        setFileUploadProgress('Uploading file...');
        const uploaded = await uploadFileToCloudinary(selectedFile);
        finalUrl = uploaded.url;
        finalFileSize = uploaded.fileSizeLabel;
        setFileUploadProgress(null);
      } catch (err: any) {
        setIsFileUploading(false);
        setFileUploadProgress(null);
        setIsSubmitting(false);
        setMessage({ type: 'error', text: err.message || 'File upload failed. Please try again.' });
        return;
      }
      setIsFileUploading(false);
    }

    const tags = tagsInput
      .split(',')
      .map(t => t.trim())
      .filter(Boolean);

    try {
      let synced = true;
      if (editingId) {
        // Update
        const r = await updateResourceItem(editingId, {
          title: title.trim(),
          description: description.trim(),
          category,
          branch,
          semester,
          subject: subject.trim() || 'General',
          url: finalUrl,
          academicYear,
          fileSize: finalFileSize,
          isPinned,
          tags
        });
        synced = r.synced;
      } else {
        // Create
        const r = await uploadResource({
          title: title.trim(),
          description: description.trim(),
          category,
          branch,
          semester,
          subject: subject.trim() || 'General',
          url: finalUrl,
          type: sourceMode === 'file' ? 'pdf' : (isDriveUrl(finalUrl) ? 'drive' : 'link'),
          academicYear,
          fileSize: finalFileSize,
          uploadedBy: 'BTEUP Admin',
          isPinned,
          tags
        });
        synced = r.synced;
      }

      setMessage(synced
        ? { type: 'success', text: editingId ? 'Resource updated successfully!' : 'New resource published to portal!' }
        : { type: 'error', text: 'Saved on this device only - the cloud database rejected the change, so other visitors will NOT see it. Make sure you are logged in as admin and the Firestore rules are published.' });

      onRefreshResources();
      resetForm();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to save resource.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string, itemTitle: string) => {
    if (window.confirm(`Are you sure you want to delete "${itemTitle}"?`)) {
      const { synced } = await deleteResourceItem(id);
      onRefreshResources();
      setMessage(synced
        ? { type: 'success', text: 'Resource deleted for everyone.' }
        : { type: 'error', text: 'Deleted on this device only - cloud delete was rejected. Check admin login and Firestore rules.' });
    }
  };

  const handleRequestStatusChange = (id: string, status: 'pending' | 'in-progress' | 'fulfilled') => {
    updateRequestStatus(id, status);
    setRequests(getSavedRequests());
  };

  const filteredManageResources = resources.filter(r => 
    r.title.toLowerCase().includes(manageSearch.toLowerCase()) ||
    r.subject.toLowerCase().includes(manageSearch.toLowerCase()) ||
    r.branch.toLowerCase().includes(manageSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div 
        id="admin-panel-modal"
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden my-auto"
      >
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold flex items-center gap-2">
                BTEUP Admin Control Panel
              </h2>
              <p className="text-xs text-slate-400">Upload syllabus, handwritten notes, PYQ papers, and manage portal contents</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex overflow-x-auto border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 px-6 shrink-0">
          <button
            onClick={() => { setActiveTab('upload'); resetForm(); }}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 ${
              activeTab === 'upload'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>{editingId ? 'Edit Resource' : 'Upload New Material'}</span>
          </button>

          <button
            onClick={() => { setActiveTab('manage'); setMessage(null); }}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 ${
              activeTab === 'manage'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Manage All Items ({resources.length})</span>
          </button>

          <button
            onClick={() => { setActiveTab('requests'); setMessage(null); syncRequestsFromCloud().then(() => setRequests(getSavedRequests())); }}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 ${
              activeTab === 'requests'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Student Note Requests</span>
            {requests.filter(r => r.status === 'pending').length > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                {requests.filter(r => r.status === 'pending').length}
              </span>
            )}
          </button>

          <button
            onClick={() => { setActiveTab('notice'); setMessage(null); fetchHomeNotice().then(n => setNotice(n)).catch(() => {}); }}
            className={`py-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 ${
              activeTab === 'notice'
                ? 'border-blue-600 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>Home Notice</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6">
          
          {/* Messages Alert */}
          {message && (
            <div className={`mb-6 p-4 rounded-xl flex items-center gap-3 text-sm font-semibold ${
              message.type === 'success' 
                ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800' 
                : 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
            }`}>
              {message.type === 'success' ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
              <span>{message.text}</span>
            </div>
          )}

          {/* TAB 1: UPLOAD / EDIT FORM */}
          {activeTab === 'upload' && (
            <form onSubmit={handleSubmit} className="space-y-5">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* Title */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Resource Title (Required) *
                  </label>
                  <input
                    id="admin-input-title"
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Applied Mathematics - I Solved Question Paper 2024"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Category *
                  </label>
                  <select
                    id="admin-input-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ResourceCategory)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="Notes">Study Notes / PDF</option>
                    <option value="Syllabus">Official Syllabus</option>
                    <option value="Paper">Previous Year Paper (PYQ)</option>
                    <option value="ModelPaper">Solved Model Paper</option>
                    <option value="Link">Important Circular / Web Link</option>
                  </select>
                </div>

                {/* Target Branch */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Target Branch *
                  </label>
                  <select
                    id="admin-input-branch"
                    value={branch}
                    onChange={(e) => setBranch(e.target.value as BranchCode)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="ALL">All Branches (1st Year Common)</option>
                    <option value="CSE">Computer Science & Engg. (CSE)</option>
                    <option value="ME">Mechanical Engg. (ME)</option>
                    <option value="CE">Civil Engg. (CE)</option>
                    <option value="EE">Electrical Engg. (EE)</option>
                    <option value="EEE">Electrical & Electronics Engg. (EEE)</option>
                  </select>
                </div>

                {/* Semester */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Semester
                  </label>
                  <select
                    id="admin-input-semester"
                    value={semester}
                    onChange={(e) => setSemester(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  >
                    <option value="1">Semester 1</option>
                    <option value="2">Semester 2</option>
                    <option value="3">Semester 3</option>
                    <option value="4">Semester 4</option>
                    <option value="5">Semester 5</option>
                    <option value="6">Semester 6</option>
                    <option value="All">All Semesters</option>
                  </select>
                </div>

                {/* Subject Name */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Subject Name
                  </label>
                  <input
                    id="admin-input-subject"
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Data Structures, Applied Physics"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Source: Link OR direct File Upload */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Document Source (Required) *
                  </label>

                  {/* Toggle */}
                  <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 mb-3 text-xs font-bold w-full sm:w-72">
                    <button
                      type="button"
                      onClick={() => { setSourceMode('link'); setSelectedFile(null); }}
                      className={`flex-1 py-2 rounded-lg transition-colors ${
                        sourceMode === 'link'
                          ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      Paste Link
                    </button>
                    <button
                      type="button"
                      onClick={() => setSourceMode('file')}
                      className={`flex-1 py-2 rounded-lg transition-colors ${
                        sourceMode === 'file'
                          ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-sm'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      Upload PDF / Image
                    </button>
                  </div>

                  {sourceMode === 'link' ? (
                    <>
                      <div className="relative">
                        <input
                          id="admin-input-url"
                          type="text"
                          value={url}
                          onChange={(e) => setUrl(e.target.value)}
                          placeholder="Paste link: https://drive.google.com/file/d/.../view?usp=sharing"
                          className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs sm:text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                        />
                      </div>
                      {detectedDriveId ? (
                        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Valid Google Drive file ID detected ({detectedDriveId}). In-app preview and direct download enabled!</span>
                        </div>
                      ) : url ? (
                        <div className="mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                          Standard web URL provided.
                        </div>
                      ) : null}
                    </>
                  ) : (
                    <>
                      <input
                        id="admin-input-file"
                        type="file"
                        accept="application/pdf,image/*"
                        onChange={(e) => {
                          const f = e.target.files && e.target.files[0] ? e.target.files[0] : null;
                          setSelectedFile(f);
                          if (f) {
                            const kind = f.type.startsWith('image/') ? 'Image' : 'PDF';
                            setFileSize(kind);
                          }
                        }}
                        className="w-full px-4 py-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs sm:text-sm outline-none file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-blue-600 file:text-white file:text-xs file:font-bold hover:file:bg-blue-700"
                      />
                      {selectedFile && (
                        <div className="mt-1.5 flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>{selectedFile.name} selected ({(selectedFile.size / (1024 * 1024)).toFixed(1)} MB)</span>
                        </div>
                      )}
                      {!CLOUDINARY_CONFIGURED && (
                        <div className="mt-1.5 text-xs text-amber-600 dark:text-amber-400 font-semibold">
                          File upload storage isn't set up yet. Direct file uploads won't work until Cloudinary credentials are added.
                        </div>
                      )}
                      {fileUploadProgress && (
                        <div className="mt-1.5 text-xs text-blue-600 dark:text-blue-400 font-semibold">
                          {fileUploadProgress}
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Academic Year */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Academic Session
                  </label>
                  <input
                    type="text"
                    value={academicYear}
                    onChange={(e) => setAcademicYear(e.target.value)}
                    placeholder="2026-27"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
                  />
                </div>

                {/* Format */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Format
                  </label>
                  <select
                    value={fileSize}
                    disabled={sourceMode === 'file'}
                    onChange={(e) => setFileSize(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none disabled:opacity-60"
                  >
                    <option value="PDF">PDF</option>
                    <option value="Image">Image</option>
                  </select>
                </div>

                {/* Tags */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Search Tags (Comma separated)
                  </label>
                  <input
                    type="text"
                    value={tagsInput}
                    onChange={(e) => setTagsInput(e.target.value)}
                    placeholder="e.g. Maths, Handwritten, Formula Sheet, Important Questions"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
                  />
                </div>

                {/* Description */}
                <div className="md:col-span-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Brief Description
                  </label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Provide details about units covered, author notes, or recurring board questions..."
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none"
                  />
                </div>

                {/* Pinned Checkbox */}
                <div className="md:col-span-2 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="admin-pin-checkbox"
                    checked={isPinned}
                    onChange={(e) => setIsPinned(e.target.checked)}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="admin-pin-checkbox" className="text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                    Feature on Homepage (Pin to top)
                  </label>
                </div>

              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  id="admin-submit-resource-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-md transition transform active:scale-95 flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  <span>{isFileUploading ? 'Uploading file...' : isSubmitting ? 'Publishing...' : (editingId ? 'Save Modifications' : 'Publish Resource to BTEUP Portal')}</span>
                </button>

                {editingId && (
                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-4 py-3 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-sm rounded-xl transition"
                  >
                    Cancel Editing
                  </button>
                )}
              </div>

            </form>
          )}

          {/* TAB 2: MANAGE ALL ITEMS */}
          {activeTab === 'manage' && (
            <div>
              <div className="mb-4">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={manageSearch}
                    onChange={(e) => setManageSearch(e.target.value)}
                    placeholder="Filter uploaded items by title, branch, subject..."
                    className="w-full pl-9 pr-4 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div className="space-y-3">
                {filteredManageResources.length === 0 ? (
                  <div className="text-center py-12 text-slate-500 text-sm">No items found matching search.</div>
                ) : (
                  filteredManageResources.map((item) => (
                    <div
                      key={item.id}
                      className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div className="overflow-hidden">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                            {item.category}
                          </span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                            {item.branch} (Sem {item.semester})
                          </span>
                          {item.isPinned && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 flex items-center gap-0.5">
                              <Pin className="w-2.5 h-2.5" /> Pinned
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                          {item.title}
                        </h4>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono truncate">
                          {item.url}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                        <button
                          onClick={() => handleEditClick(item)}
                          className="p-2 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:text-blue-600 transition"
                          title="Edit"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDelete(item.id, item.title)}
                          className="p-2 rounded-lg bg-red-50 dark:bg-red-950/40 text-red-600 hover:bg-red-100 transition"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: STUDENT REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                Diploma students submit requests for missing chapter notes, unsolved question papers, or syllabus clarification.
              </div>

              {requests.length === 0 && (
                <div className="text-center py-12 text-slate-500 text-sm">No student requests yet.</div>
              )}

              {requests.map(req => (
                <div 
                  key={req.id}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/60"
                >
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {req.subject}
                      </span>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        Requested by <span className="font-semibold text-slate-700 dark:text-slate-300">{req.studentName}</span> ({req.studentEmail}) • {req.branch} (Sem {req.semester})
                      </div>
                    </div>

                    <select
                      value={req.status}
                      onChange={(e) => handleRequestStatusChange(req.id, e.target.value as any)}
                      className={`text-xs font-bold px-2.5 py-1 rounded-lg border outline-none ${
                        req.status === 'fulfilled'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-300'
                          : req.status === 'in-progress'
                          ? 'bg-blue-50 text-blue-700 border-blue-300 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-amber-50 text-amber-700 border-amber-300 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      <option value="pending">Pending</option>
                      <option value="in-progress">In-Progress</option>
                      <option value="fulfilled">Fulfilled</option>
                    </select>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                    "{req.details}"
                  </p>
                </div>
              ))}
            </div>
          )}


          {/* TAB 4: HOME PAGE NOTICE */}
          {activeTab === 'notice' && (
            <form onSubmit={handleSaveNotice} className="space-y-5 max-w-2xl">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                This is the red "Latest Notice" bar at the top of the homepage. Changes are visible to every visitor.
              </p>

              {/* Live preview */}
              <div className="rounded-xl bg-slate-900 text-white text-xs py-2.5 px-3 flex items-center gap-2.5 overflow-hidden">
                <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500 font-bold text-[10px] uppercase tracking-wider shrink-0">
                  <Bell className="w-3 h-3" /> Latest Notice
                </span>
                <span className="truncate font-medium text-slate-200">{notice.title || 'Your notice text will appear here'}</span>
                <span className="ml-auto font-mono text-slate-400 shrink-0 hidden sm:inline">{notice.date}</span>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Notice Text *
                </label>
                <textarea
                  rows={2}
                  maxLength={220}
                  value={notice.title}
                  onChange={(e) => setNotice({ ...notice, title: e.target.value })}
                  placeholder="e.g. BTEUP Odd Semester Exam Form last date extended to 20 Oct 2026"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none focus:ring-2 focus:ring-blue-500"
                />
                <div className="text-[11px] text-slate-400 mt-1 text-right">{notice.title.length}/220</div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    Date shown
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={notice.date}
                      onChange={(e) => setNotice({ ...notice, date: e.target.value })}
                      placeholder="09 Oct 2026"
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setNotice({ ...notice, date: todayLabel() })}
                      className="px-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold whitespace-nowrap hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                    >
                      Today
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                    "View Notice" link (optional)
                  </label>
                  <input
                    type="text"
                    value={notice.link}
                    onChange={(e) => setNotice({ ...notice, link: e.target.value })}
                    placeholder="https://bteup.ac.in"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-xs sm:text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="admin-notice-visible"
                  checked={notice.visible}
                  onChange={(e) => setNotice({ ...notice, visible: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="admin-notice-visible" className="text-xs font-bold text-slate-700 dark:text-slate-300 cursor-pointer">
                  Show notice on homepage
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="submit"
                  disabled={noticeSaving}
                  className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl shadow-md transition active:scale-95 flex items-center gap-2"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{noticeSaving ? 'Saving...' : 'Save Notice'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNotice(getDefaultHomeNotice())}
                  className="px-4 py-3 bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-sm rounded-xl transition"
                >
                  Clear
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
