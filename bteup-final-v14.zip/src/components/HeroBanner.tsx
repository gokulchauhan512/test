import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  CheckCircle2, 
  Bell, 
  BookOpen, 
  ArrowRight,
  ShieldAlert,
  GraduationCap,
  Layers
} from 'lucide-react';
import { fetchHomeNotice, getCachedHomeNotice, HomeNotice } from '../services/firebase';
import { safeHttpUrl } from '../utils/driveHelper';
import { BranchCode, ResourceCategory } from '../types';

interface HeroBannerProps {
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSelectCategory: (category: ResourceCategory | 'All') => void;
  onSelectBranch: (branch: BranchCode) => void;
  onSearchSubmit: () => void;
  totalResourcesCount: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  searchQuery,
  setSearchQuery,
  onSelectCategory,
  onSelectBranch,
  onSearchSubmit,
  totalResourcesCount
}) => {
  // Latest notice - editable by the admin (Admin Panel -> Home Notice)
  const [notice, setNotice] = useState<HomeNotice>(() => getCachedHomeNotice());
  useEffect(() => {
    let alive = true;
    fetchHomeNotice().then(n => { if (alive) setNotice(n); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  // Soft mouse parallax for the floating orbs (CSS variables only - no re-render)
  const heroRef = useRef<HTMLDivElement>(null);
  const onHeroMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.pointerType !== 'mouse') return;
    const el = heroRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', ((e.clientX - r.left) / r.width - 0.5).toFixed(3));
    el.style.setProperty('--my', ((e.clientY - r.top) / r.height - 0.5).toFixed(3));
  };
  const showNotice = notice.visible && notice.title.trim().length > 0;
  const noticeLink = safeHttpUrl(notice.link) || 'https://bteup.ac.in';

  return (
    <div ref={heroRef} onPointerMove={onHeroMove} className="relative overflow-hidden transition-colors duration-200">

      {/* Floating soft 3D orbs (desktop only, decorative) */}
      <div aria-hidden="true" className="hidden md:block absolute inset-0 pointer-events-none overflow-hidden">
        <div className="hero-parallax absolute right-[24%] top-[34%]" style={{ '--depth': 28 } as React.CSSProperties}>
          <div className="neu-orb w-24 h-24" />
        </div>
        <div className="hero-parallax absolute right-[7%] top-[22%]" style={{ '--depth': -20 } as React.CSSProperties}>
          <div className="neu-orb w-16 h-16" style={{ animationDelay: '-2s' }} />
        </div>
        <div className="hero-parallax absolute right-[13%] bottom-[12%]" style={{ '--depth': 36 } as React.CSSProperties}>
          <div className="neu-orb w-28 h-28" style={{ animationDelay: '-4s' }} />
        </div>
        <div className="hero-parallax absolute right-[32%] bottom-[10%]" style={{ '--depth': -30 } as React.CSSProperties}>
          <div className="neu-orb w-12 h-12" style={{ animationDelay: '-1s' }} />
        </div>
      </div>

      {/* Background Subtle Grid Effect */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#8c959f14_1px,transparent_1px),linear-gradient(to_bottom,#8c959f14_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      {/* Live Notice Ticker Banner */}
      {showNotice && (
      <div className="relative z-10 bg-slate-900 text-white text-xs py-2 px-4 border-b border-slate-700/60">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 overflow-hidden flex-1">
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-red-500 text-white font-bold text-[10px] tracking-wider uppercase animate-pulse">
              <Bell className="w-3 h-3" />
              Latest Notice
            </span>
            <p className="truncate font-medium text-slate-200 text-xs sm:text-sm">
              {notice.title}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0 text-[11px] text-slate-300">
            <span className="hidden md:inline font-mono text-slate-400">{notice.date}</span>
            <a 
              href={noticeLink} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="font-bold underline text-blue-300 hover:text-white transition-colors flex items-center gap-1"
            >
              View Notice <ArrowRight className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
      )}

      {/* Main Hero Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 relative z-10">
        <div className="max-w-3xl text-left">
          
          {/* Heading */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-light text-slate-900 dark:text-white tracking-tight leading-[1.2] mb-5">
            Syllabus, notes and question papers for <span className="font-semibold">BTEUP diploma</span> students
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 font-normal leading-relaxed mb-8 max-w-2xl">
            Branch-wise syllabus, handwritten notes and previous year question papers for UP Polytechnic.
            Open a file in your browser or download it from Google Drive.
          </p>

          {/* Instant Search Bar */}
          <div className="relative max-w-2xl mb-8 rounded-2xl">
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                onSearchSubmit();
              }} 
              className="relative flex items-center neu-inset rounded-2xl border border-transparent focus-within:border-blue-500/60 transition-all p-1.5 sm:p-2"
            >
              <div className="pl-3 pr-2 text-slate-400">
                <Search className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <input
                id="hero-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search subject, branch, code (e.g. Maths-I, CSE, SOM, EDC)..."
                className="w-full bg-transparent text-slate-900 dark:text-white placeholder-slate-400 text-sm sm:text-base font-medium outline-none py-2 px-1"
              />
              <button
                id="hero-search-submit-btn"
                type="submit"
                className="shrink-0 px-5 sm:px-7 py-2.5 sm:py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm sm:text-base rounded-xl transition-transform active:scale-95 shadow-md shadow-blue-600/30 flex items-center gap-2"
              >
                <span>Find</span>
                <ArrowRight className="w-4 h-4 hidden sm:inline" />
              </button>
            </form>
          </div>

          {/* Key Trust Badges */}
          <div className="flex flex-wrap items-center justify-start gap-x-6 gap-y-3 text-xs sm:text-sm font-semibold text-slate-600 dark:text-slate-400">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-slate-500 dark:text-slate-400" />
              <span>Downloads do not need an account</span>
            </div>
            {totalResourcesCount > 0 && (
              <div className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-slate-500 dark:text-slate-400" />
                <span>{totalResourcesCount} {totalResourcesCount === 1 ? 'document' : 'documents'} available</span>
              </div>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
