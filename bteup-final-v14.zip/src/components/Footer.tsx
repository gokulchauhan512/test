import { BrandLogo } from './BrandLogo';
import React from 'react';
import { 
  GraduationCap, 
  AlertTriangle, 
  ExternalLink, 
  Heart, 
  ShieldAlert, 
  FileText, 
  FolderDown, 
  CheckCircle,
  Eye
} from 'lucide-react';
import { BranchCode } from '../types';

interface FooterProps {
  onSelectBranch: (branch: BranchCode) => void;
  onOpenRequestModal: () => void;
  visitorCount?: number;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectBranch,
  onOpenRequestModal,
  visitorCount = 0
}) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 transition-colors">
      
      {/* EXPLICIT MANDATORY DISCLAIMER CALLOUT BANNER */}
      <div className="bg-amber-950/60 border-b border-amber-900/50 py-4 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-start sm:items-center gap-3 text-amber-200 text-xs sm:text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5 sm:mt-0" />
          <p className="leading-relaxed font-medium">
            <strong className="text-white font-bold">Important Disclaimer:</strong> This is NOT an official website of BTEUP (Board of Technical Education Uttar Pradesh, Lucknow). 
            This portal is an independent student-led open educational initiative designed exclusively to help polytechnic diploma students easily access study notes, revised syllabus, and past year question papers. For official notifications, examination schedules, and authentic announcements, please always refer to the official board portal at <a href="https://bteup.ac.in" target="_blank" rel="noopener noreferrer" className="underline font-bold text-white hover:text-amber-300">bteup.ac.in</a> or <a href="https://urise.up.gov.in" target="_blank" rel="noopener noreferrer" className="underline font-bold text-white hover:text-amber-300">urise.up.gov.in</a>.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          
          {/* Col 1: Brand & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <BrandLogo heightClass="h-10" />
              <span className="text-2xl font-black text-white tracking-tight">BTE<span className="text-blue-400">UP</span> Vault</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Study resource portal for UP Polytechnic diploma students: syllabus, notes and previous year question papers. Files are hosted on Google Drive. There is no paywall, and no account is needed to download.
            </p>
            {visitorCount > 0 && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
                <Eye className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-slate-300">Total visitors:</span>
                <span className="font-bold text-white tabular-nums">{visitorCount.toLocaleString('en-IN')}</span>
              </div>
            )}
            <div className="pt-1">
              <button
                onClick={onOpenRequestModal}
                className="text-xs font-bold px-3.5 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 transition flex items-center gap-1.5"
              >
                <span>Request Missing Notes / PYQ</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Col 2: Polytechnic Branches */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Diploma Branches
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onSelectBranch('CSE')} className="hover:text-white transition">
                  Computer Science & Engineering (355)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectBranch('ME')} className="hover:text-white transition">
                  Mechanical Engineering (Prod / Auto - 343)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectBranch('CE')} className="hover:text-white transition">
                  Civil Engineering (322)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectBranch('EE')} className="hover:text-white transition">
                  Electrical Engineering (328)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectBranch('EEE')} className="hover:text-white transition">
                  Electronics & Communication Engg. (330)
                </button>
              </li>
              <li>
                <button onClick={() => onSelectBranch('ALL')} className="hover:text-white transition">
                  First Year Common Subjects (All Branches)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Resources */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Study Materials
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#resources-catalog" className="hover:text-white transition">Latest BTEUP Syllabus Copies</a></li>
              <li><a href="#resources-catalog" className="hover:text-white transition">Handwritten Chapter Notes</a></li>
              <li><a href="#resources-catalog" className="hover:text-white transition">Semester Exam Papers (2020-2024)</a></li>
              <li><a href="#resources-catalog" className="hover:text-white transition">Solved Model Papers & Numericals</a></li>
              <li><a href="#resources-catalog" className="hover:text-white transition">Formula Cheatsheets</a></li>
              <li><a href="#official-links-section" className="hover:text-white transition">Exam Timetable & Date Sheet</a></li>
            </ul>
          </div>

          {/* Col 4: Official Portals */}
          <div>
            <h4 className="text-sm font-bold uppercase tracking-wider text-white mb-4">
              Official Boards
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="https://bteup.ac.in" target="_blank" rel="noopener noreferrer" className="hover:text-white transition flex items-center justify-between">
                  <span>BTEUP Official Website</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://urise.up.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-white transition flex items-center justify-between">
                  <span>U-Rise Student Portal</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://result.bteexam.com" target="_blank" rel="noopener noreferrer" className="hover:text-white transition flex items-center justify-between">
                  <span>Semester Exam Results</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://scholarship.up.gov.in" target="_blank" rel="noopener noreferrer" className="hover:text-white transition flex items-center justify-between">
                  <span>UP State Scholarship Portal</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
              <li>
                <a href="https://janhit.bteup.ac.in" target="_blank" rel="noopener noreferrer" className="hover:text-white transition flex items-center justify-between">
                  <span>Janhit Guarantee Services</span>
                  <ExternalLink className="w-3 h-3 text-slate-500" />
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} BTEUP Vault. Unofficial educational resource, not affiliated with BTEUP or the Government of Uttar Pradesh.</p>
          <div className="flex items-center gap-5 text-slate-400">
            <a href="/terms/" className="hover:text-white transition">Terms and Conditions</a>
            <a href="/privacy/" className="hover:text-white transition">Privacy Policy</a>
          </div>
        </div>

      </div>
    </footer>
  );
};
