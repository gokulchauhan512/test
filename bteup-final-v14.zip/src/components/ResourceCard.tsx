import React from 'react';
import { 
  Download, 
  Eye, 
  Bookmark, 
  BookmarkCheck, 
  Trash2, 
  Edit3, 
  Pin,
  Calendar,
  Layers,
  HardDrive
} from 'lucide-react';
import { ResourceItem } from '../types';
import { useAuth } from '../context/AuthContext';
import { normalizeFormat } from '../utils/format';

interface ResourceCardProps {
  resource: ResourceItem;
  onPreview: (resource: ResourceItem) => void;
  onDownload: (resource: ResourceItem) => void;
  onEdit?: (resource: ResourceItem) => void;
  onDelete?: (id: string) => void;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({
  resource,
  onPreview,
  onDownload,
  onEdit,
  onDelete
}) => {
  const { bookmarks, toggleBookmark, isAdmin } = useAuth();
  const isBookmarked = bookmarks.includes(resource.id);

  const getCategoryBadgeColor = (cat: string) => {
    switch (cat) {
      case 'Syllabus':
        return 'bg-purple-100 text-purple-700 dark:bg-purple-950/70 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'Paper':
        return 'bg-rose-100 text-rose-700 dark:bg-rose-950/70 dark:text-rose-300 border-rose-200 dark:border-rose-800';
      case 'Notes':
        return 'bg-blue-100 text-blue-700 dark:bg-blue-950/70 dark:text-blue-300 border-blue-200 dark:border-blue-800';
      case 'ModelPaper':
        return 'bg-amber-100 text-amber-700 dark:bg-amber-950/70 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      default:
        return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/70 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
    }
  };

  const getCategoryLabel = (cat: string) => {
    switch (cat) {
      case 'Syllabus': return 'Official Syllabus';
      case 'Paper': return 'Previous Year Paper';
      case 'Notes': return 'Study Notes / PDF';
      case 'ModelPaper': return 'Solved Model Paper';
      case 'Link': return 'Important Circular';
      default: return cat;
    }
  };

  return (
    <div 
      id={`resource-card-${resource.id}`}
      className="neu neu-hover tilt-3d rounded-2xl p-5 sm:p-6 h-full flex flex-col justify-between group relative"
    >
      {/* Pinned Tag */}
      {resource.isPinned && (
        <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2">
          <span className="inline-flex items-center gap-1 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm">
            <Pin className="w-2.5 h-2.5" /> Featured
          </span>
        </div>
      )}

      <div>
        {/* Badges Header */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md border ${getCategoryBadgeColor(resource.category)}`}>
              {getCategoryLabel(resource.category)}
            </span>
            <span className="text-[11px] font-mono font-bold px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
              {resource.branch === 'ALL' ? 'Common' : resource.branch}
            </span>
            <span className="text-[11px] font-medium px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
              {resource.semester === 'All' ? 'All Sem' : `Sem ${resource.semester}`}
            </span>
          </div>

          <button
            id={`bookmark-btn-${resource.id}`}
            onClick={() => toggleBookmark(resource.id)}
            title={isBookmarked ? 'Remove Bookmark' : 'Save Bookmark'}
            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {isBookmarked ? (
              <BookmarkCheck className="w-5 h-5 text-amber-500 fill-amber-500" />
            ) : (
              <Bookmark className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Title */}
        <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2 leading-snug group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {resource.title}
        </h3>

        {/* Subject Tag */}
        <div className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 mb-2.5">
          <Layers className="w-3.5 h-3.5" />
          <span>{resource.subject}</span>
        </div>

        {/* Description */}
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed mb-4">
          {resource.description}
        </p>

        {/* Meta Info */}
        <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400 mb-5 font-medium">
          {resource.academicYear && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {resource.academicYear}
            </span>
          )}
          {resource.fileSize && (
            <span className="flex items-center gap-1">
              <HardDrive className="w-3 h-3" />
              {normalizeFormat(resource.fileSize)}
            </span>
          )}
          <span className="text-slate-400">
            {resource.downloadsCount || 0} downloads
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div>
        <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            id={`preview-btn-${resource.id}`}
            onClick={() => onPreview(resource)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl neu-sm neu-press text-slate-700 dark:text-slate-200 text-xs font-bold hover:text-blue-600 dark:hover:text-blue-400 transition"
          >
            <Eye className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Preview</span>
          </button>

          <button
            id={`download-btn-${resource.id}`}
            onClick={() => onDownload(resource)}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-sm shadow-blue-500/20 transition active:scale-95"
            title="Direct download (no sign-in required)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>
        </div>

        {/* Admin Controls */}
        {isAdmin && (
          <div className="flex items-center justify-between gap-2 mt-3 pt-2 border-t border-dashed border-slate-200 dark:border-slate-800 text-[11px]">
            <span className="text-slate-400 font-mono text-[10px]">Admin:</span>
            <div className="flex items-center gap-2">
              {onEdit && (
                <button
                  onClick={() => onEdit(resource)}
                  className="p-1 text-slate-500 hover:text-blue-600 transition"
                  title="Edit details"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
              )}
              {onDelete && (
                <button
                  onClick={() => {
                    if (window.confirm(`Delete "${resource.title}"?`)) {
                      onDelete(resource.id);
                    }
                  }}
                  className="p-1 text-slate-500 hover:text-red-600 transition"
                  title="Delete resource"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
