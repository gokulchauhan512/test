import React from 'react';
import { Reveal } from './Reveal';
import { 
  Globe, 
  GraduationCap, 
  FileCheck, 
  BookOpen, 
  Award, 
  FileText, 
  ExternalLink,
  ShieldCheck,
  Building
} from 'lucide-react';
import { OFFICIAL_BTEUP_LINKS } from '../data/initialResources';

export const ImportantLinksSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Globe': return <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />;
      case 'GraduationCap': return <GraduationCap className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      case 'FileCheck': return <FileCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
      case 'Award': return <Award className="w-5 h-5 text-rose-600 dark:text-rose-400" />;
      default: return <FileText className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
    }
  };

  return (
    <section id="official-links-section" className="py-14 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-3">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Government & Examination Portals
            </span>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight mt-1">
              Official BTEUP & UP Govt Links
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              Quick direct access to student dashboards, semester examination result servers, and scholarship schemes.
            </p>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Direct Government Web Portals</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {OFFICIAL_BTEUP_LINKS.map((link, idx) => (
            <Reveal key={idx} delay={(idx % 3) * 70} className="h-full">
            <a
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-5 rounded-2xl neu neu-hover tilt-3d group flex flex-col justify-between h-full"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="w-10 h-10 rounded-xl neu-sm flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getIcon(link.icon)}
                  </div>
                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
                    {link.badge}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors flex items-center gap-1.5">
                  <span>{link.title}</span>
                  <ExternalLink className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>

                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-4">
                  {link.desc}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                <span className="truncate">{link.url.replace('https://', '')}</span>
                <ExternalLink className="w-3.5 h-3.5 shrink-0" />
              </div>
            </a>
            </Reveal>
          ))}
        </div>

      </div>
    </section>
  );
};
