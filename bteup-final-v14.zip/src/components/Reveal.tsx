import React, { useEffect, useRef, useState } from 'react';

// One shared observer for every Reveal (cheap even with many cards)
let sharedObserver: IntersectionObserver | null = null;
const pending = new WeakMap<Element, () => void>();

function getObserver(): IntersectionObserver {
  if (!sharedObserver) {
    sharedObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          pending.get(entry.target)?.();
          pending.delete(entry.target);
          sharedObserver?.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0 });
  }
  return sharedObserver;
}

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}

/** Fades its children in once, when they scroll into view. */
// `delay` is accepted for backwards compatibility but no longer used (no staggered motion).
export const Reveal: React.FC<RevealProps> = ({ children, className = '' }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState<boolean>(() =>
    typeof IntersectionObserver === 'undefined' ||
    (typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)
  );

  useEffect(() => {
    if (shown) return;
    const el = ref.current;
    if (!el) return;
    pending.set(el, () => setShown(true));
    getObserver().observe(el);
    return () => {
      getObserver().unobserve(el);
      pending.delete(el);
    };
  }, [shown]);

  return (
    <div
      ref={ref}
      className={`reveal ${shown ? 'reveal-in' : ''} ${className}`}
    >
      {children}
    </div>
  );
};
