import React from 'react';
import { 
  Code, 
  Cog, 
  Building2, 
  Zap, 
  Cpu, 
  BookOpen, 
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { BRANCHES_DATA } from '../data/initialResources';
import { Reveal } from './Reveal';
import { BranchImage } from './BranchImage';
import { BranchCode, ResourceItem } from '../types';

interface BranchSelectorProps {
  selectedBranch: BranchCode;
  onSelectBranch: (branch: BranchCode) => void;
  resources: ResourceItem[];
}

export const BranchSelector: React.FC<BranchSelectorProps> = ({
  selectedBranch,
  onSelectBranch,
  resources
}) => {

  const getBranchIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code': return <Code className="w-6 h-6 text-blue-600 dark:text-blue-400" />;
      case 'Cog': return <Cog className="w-6 h-6 text-slate-700 dark:text-slate-300" />;
      case 'Building2': return <Building2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />;
      case 'Zap': return <Zap className="w-6 h-6 text-amber-500 dark:text-amber-400" />;
      case 'Cpu': return <Cpu className="w-6 h-6 text-cyan-600 dark:text-cyan-400" />;
      default: return <BookOpen className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />;
    }
  };

  const getBranchCount = (code: BranchCode) => {
    if (code === 'ALL') {
      return resources.filter(r => r.branch === 'ALL').length;
    }
    return resources.filter(r => r.branch === code || r.branch === 'ALL').length;
  };

  return (
    <section id="branches" className="py-14 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <Reveal>
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">Engineering Disciplines</span>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight mt-1">
            Choose Your Polytechnic Branch
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
            Select your curriculum stream to filter semester-wise syllabus, handwritten study notes, and previous year papers.
          </p>
        </div>

        {selectedBranch !== 'ALL' && (
          <button
            onClick={() => onSelectBranch('ALL')}
            className="self-start md:self-auto text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
          >
            <span>Show All Common Subjects</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      </Reveal>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
        {BRANCHES_DATA.map((branch, idx) => {
          const isSelected = selectedBranch === branch.code;
          const count = getBranchCount(branch.code);

          return (
            <Reveal key={branch.code} delay={(idx % 3) * 70} className="h-full">
            <div
              id={`branch-card-${branch.code.toLowerCase()}`}
              onClick={() => onSelectBranch(branch.code)}
              className={`cursor-pointer rounded-2xl p-6 h-full relative overflow-hidden group select-none tilt-3d ${
                isSelected
                  ? 'neu-inset ring-2 ring-blue-500/40'
                  : 'neu neu-hover'
              }`}
            >
              {/* Corner Badge */}
              <div className="relative mb-4 rounded-xl overflow-hidden neu-inset p-1">
                <BranchImage code={branch.code} alt={branch.name} fallback={getBranchIcon(branch.iconName)} />
                <span className="absolute top-3 left-3 font-mono text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-900/70 text-white backdrop-blur-sm">
                  {branch.code}
                </span>
                <span className="absolute top-3 right-3 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-white/85 dark:bg-slate-900/75 text-slate-700 dark:text-slate-200 backdrop-blur-sm">
                  {count} items
                </span>
              </div>

              {/* Branch Name */}
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1.5 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                {branch.name}
              </h3>

              {/* Description */}
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed mb-4">
                {branch.description}
              </p>

              {/* Bottom Action */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800/80 text-xs font-bold">
                <span className={isSelected ? 'text-blue-600 dark:text-blue-400 font-extrabold' : 'text-slate-600 dark:text-slate-400'}>
                  {isSelected ? 'Currently Selected' : 'Browse Vault'}
                </span>
                <ArrowRight className={`w-4 h-4 transition-transform group-hover:translate-x-1 ${isSelected ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`} />
              </div>
            </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
};
