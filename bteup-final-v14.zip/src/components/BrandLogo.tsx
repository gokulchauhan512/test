import React, { useState } from 'react';
import { GraduationCap } from 'lucide-react';

// Put your logo at  public/logo.png  (PNG/transparent works best).
// If the file is missing, the original graduation-cap badge is shown instead.
export const LOGO_SRC = '/logo.png';

export const BrandLogo: React.FC<{ heightClass?: string }> = ({ heightClass = 'h-11' }) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className={`${heightClass} aspect-square rounded-xl bg-slate-800 flex items-center justify-center text-white shadow-md shadow-blue-500/20`}>
        <GraduationCap className="w-6 h-6" />
      </div>
    );
  }

  return (
    <img
      src={LOGO_SRC}
      alt="BTEUP Vault logo"
      onError={() => setFailed(true)}
      className={`${heightClass} w-auto max-w-[150px] object-contain`}
      draggable={false}
    />
  );
};
