import { Reveal } from './Reveal';
import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  Layers, 
  BookOpen, 
  FileText, 
  FolderDown, 
  HelpCircle,
  X,
  Sparkles,
  SlidersHorizontal,
  Bookmark
} from 'lucide-react';
import { ResourceItem, BranchCode, ResourceCategory } from '../types';
import { ResourceCard } from './ResourceCard';
import { BRANCHES_DATA } from '../data/initialResources';

interface ResourceCatalogProps {
  resources: ResourceItem[];
  selectedBranch: BranchCode;
  setSelectedBranch: (b: BranchCode) => void;
  selectedCategory: ResourceCategory | 'All';
  setSelectedCategory: (c: ResourceCategory | 'All') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onPreview: (resource: ResourceItem) => void;
  onDownload: (resource: ResourceItem) => void;
  onEditResource?: (resource: ResourceItem) => void;
  onDeleteResource?: (id: string) => void;
  onOpenRequestModal: () => void;
  onlyBookmarked?: boolean;
  bookmarkedIds?: string[];
}

export const ResourceCatalog: React.FC<ResourceCatalogProps> = ({
  resources,
  selectedBranch,
  setSelectedBranch,
  selectedCategory,
  setSelectedCategory,
  searchQuery,
  setSearchQuery,
  onPreview,
  onDownload,
  onEditResource,
  onDeleteResource,
  onOpenRequestModal,
  onlyBookmarked = false,
  bookmarkedIds = []
}) => {
  const [selectedSemester, setSelectedSemester] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'popular' | 'newest' | 'title'>('popular');

  const categories: { key: ResourceCategory | 'All'; label: string }[] = [
    { key: 'All', label: 'All Resources' },
    { key: 'Syllabus', label: 'Syllabus' },
    { key: 'Notes', label: 'Notes & PDF' },
    { key: 'Paper', label: 'Previous Papers (PYQ)' },
    { key: 'ModelPaper', label: 'Model Papers' },
    { key: 'Link', label: 'Important Links' },
  ];

  const semesters = ['All', '1', '2', '3', '4', '5', '6'];

  const filteredResources = useMemo(() => {
    return resources.filter(item => {
      // Bookmarks filter
      if (onlyBookmarked && !bookmarkedIds.includes(item.id)) {
        return false;
      }

      // Branch filter: if selectedBranch is NOT ALL, match branch or ALL
      if (selectedBranch !== 'ALL' && item.branch !== selectedBranch && item.branch !== 'ALL') {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'All' && item.category !== selectedCategory) {
        return false;
      }

      // Semester filter
      if (selectedSemester !== 'All' && item.semester !== selectedSemester && item.semester !== 'All') {
        return false;
      }

      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const inTitle = item.title.toLowerCase().includes(q);
        const inDesc = item.description.toLowerCase().includes(q);
        const inSubj = item.subject.toLowerCase().includes(q);
        const inBranch = item.branch.toLowerCase().includes(q);
        const inTags = (item.tags || []).some(t => t.toLowerCase().includes(q));
        if (!inTitle && !inDesc && !inSubj && !inBranch && !inTags) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'popular') return (b.downloadsCount || 0) - (a.downloadsCount || 0);
      if (sortBy === 'newest') return (b.createdAt || 0) - (a.createdAt || 0);
      return a.title.localeCompare(b.title);
    });
  }, [resources, selectedBranch, selectedCategory, selectedSemester, searchQuery, sortBy, onlyBookmarked, bookmarkedIds]);

  const currentBranchInfo = BRANCHES_DATA.find(b => b.code === selectedBranch);

  return (
    <section id="resources-catalog" className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Title & Filter Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              {onlyBookmarked ? 'Personal Study List' : 'Digital Vault Directory'}
            </span>
            {onlyBookmarked && (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                Bookmarked Items
              </span>
            )}
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight mt-1">
            {onlyBookmarked 
              ? 'Your Saved Study Materials' 
              : currentBranchInfo 
              ? `${currentBranchInfo.name} Study Repository` 
              : 'Browse All Study Materials'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Showing verified curriculum notes and papers. Direct download enabled without sign-in.
          </p>
        </div>

        {/* Quick Search & Sort Bar */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search in this branch..."
              className="w-full pl-9 pr-8 py-2 text-xs sm:text-sm rounded-xl neu-inset border border-transparent text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-2 text-xs font-semibold rounded-xl neu-inset border border-transparent text-slate-700 dark:text-slate-300 outline-none"
          >
            <option value="popular">Most Downloaded</option>
            <option value="newest">Newest First</option>
            <option value="title">Alphabetical (A-Z)</option>
          </select>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-4 scrollbar-none">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.key;
          return (
            <button
              key={cat.key}
              id={`cat-filter-btn-${cat.key.toLowerCase()}`}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all select-none ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                  : 'neu-sm neu-press text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Branch & Semester Pills Filter Bar */}
      <div className="neu p-4 rounded-2xl mb-8 flex flex-wrap items-center justify-between gap-4">
        
        {/* Branch Selector Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-400 uppercase mr-1">Branch:</span>
          {BRANCHES_DATA.map(b => (
            <button
              key={b.code}
              onClick={() => setSelectedBranch(b.code)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                selectedBranch === b.code
                  ? 'neu-inset text-blue-700 dark:text-blue-300'
                  : 'neu-sm neu-press text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              {b.shortName}
            </button>
          ))}
        </div>

        {/* Semester Selector Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-400 uppercase mr-1">Semester:</span>
          {semesters.map(sem => (
            <button
              key={sem}
              onClick={() => setSelectedSemester(sem)}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                selectedSemester === sem
                  ? 'neu-inset text-blue-700 dark:text-blue-300'
                  : 'neu-sm neu-press text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400'
              }`}
            >
              {sem === 'All' ? 'All Sem' : `Sem ${sem}`}
            </button>
          ))}
        </div>

      </div>

      {/* Resource Cards Grid */}
      {filteredResources.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map((res, i) => (
            <Reveal key={res.id} delay={(i % 3) * 70} className="h-full">
              <ResourceCard
                resource={res}
                onPreview={onPreview}
                onDownload={onDownload}
                onEdit={onEditResource}
                onDelete={onDeleteResource}
              />
            </Reveal>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="neu rounded-2xl p-12 text-center max-w-xl mx-auto">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
            No Materials Found
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
            No files currently match your search criteria for branch <strong>{selectedBranch}</strong> and category <strong>{selectedCategory}</strong>.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => {
                setSelectedBranch('ALL');
                setSelectedCategory('All');
                setSelectedSemester('All');
                setSearchQuery('');
              }}
              className="px-4 py-2 neu-sm neu-press text-slate-800 dark:text-slate-200 text-xs font-bold rounded-xl transition"
            >
              Reset Filters
            </button>
            <button
              onClick={onOpenRequestModal}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition"
            >
              Request Admin to Upload
            </button>
          </div>
        </div>
      )}

    </section>
  );
};
