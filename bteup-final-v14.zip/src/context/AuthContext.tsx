import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  auth, 
  ADMIN_EMAIL,
  saveUserProfileToFirestore,
  fetchUserProfileFromFirestore
} from '../services/firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import { UserProfile, BranchCode } from '../types';

interface AuthContextType {
  user: UserProfile | null;
  isAdmin: boolean;
  isLoading: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; message: string }>;
  register: (data: { email: string; pass: string; name: string; branch: BranchCode; semester: string; college: string; mobile: string }) => Promise<{ success: boolean; message: string }>;
  logout: () => Promise<void>;
  toggleBookmark: (resourceId: string) => void;
  bookmarks: string[];
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_USER_STATE = 'bteup_current_user_profile';
const LOCAL_BOOKMARKS_KEY = 'bteup_user_bookmarks';

function friendlyAuthError(err: any): string {
  switch (err?.code) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Invalid email or password.';
    case 'auth/invalid-email':
      return 'Please enter a valid email address.';
    case 'auth/email-already-in-use':
      return 'This email is already registered. Please log in instead.';
    case 'auth/weak-password':
      return 'Password must be at least 6 characters.';
    case 'auth/too-many-requests':
      return 'Too many attempts. Please wait a few minutes and try again.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your internet connection.';
    default:
      return 'Something went wrong. Please try again.';
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  // While a registration is in progress, register() builds the profile itself (with branch/semester/college)
  const registeringRef = useRef(false);
  const [bookmarks, setBookmarks] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_BOOKMARKS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    // 2. Firebase onAuthStateChanged listener
    if (auth) {
      const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
        if (registeringRef.current) {
          setIsLoading(false);
          return;
        }
        if (fbUser && fbUser.email) {
          const isAdminUser = fbUser.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
          let profile: UserProfile = {
            uid: fbUser.uid,
            email: fbUser.email,
            displayName: fbUser.displayName || (isAdminUser ? 'BTEUP Administrator' : fbUser.email.split('@')[0]),
            role: isAdminUser ? 'admin' : 'student',
            bookmarks: bookmarks
          };
          // Enrich with full profile (branch, semester, college) saved in Firestore
          const cloudProfile = await fetchUserProfileFromFirestore(fbUser.uid);
          if (cloudProfile) {
            profile = { ...profile, ...cloudProfile, bookmarks: bookmarks };
          }
          setUser(profile);
          localStorage.setItem(LOCAL_USER_STATE, JSON.stringify(profile));
        } else {
          // Session comes only from Firebase - never from editable browser storage
          setUser(null);
          localStorage.removeItem(LOCAL_USER_STATE);
        }
        setIsLoading(false);
      });
      return () => unsubscribe();
    } else {
      setIsLoading(false);
    }
  }, []);

  const login = async (email: string, pass: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    
    // First try Firebase Auth
    if (auth) {
      try {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, pass);
        const isAdminUser = cred.user.email?.toLowerCase() === ADMIN_EMAIL.toLowerCase();
        let profile: UserProfile = {
          uid: cred.user.uid,
          email: cred.user.email || cleanEmail,
          displayName: cred.user.displayName || (isAdminUser ? 'BTEUP Administrator' : cleanEmail.split('@')[0]),
          role: isAdminUser ? 'admin' : 'student',
          bookmarks: bookmarks
        };
        const cloudProfile = await fetchUserProfileFromFirestore(cred.user.uid);
        if (cloudProfile) {
          profile = { ...profile, ...cloudProfile, bookmarks: bookmarks };
        }
        setUser(profile);
        localStorage.setItem(LOCAL_USER_STATE, JSON.stringify(profile));
        return { success: true, message: isAdminUser ? 'Welcome Admin! Control panel unlocked.' : 'Login successful!' };
      } catch (fbErr: any) {
        console.warn("Firebase sign in notice:", fbErr.code);
        return { success: false, message: friendlyAuthError(fbErr) };
      }
    }

    return { success: false, message: 'Login service is unavailable right now. Please try again later.' };
  };

  const register = async (data: { email: string; pass: string; name: string; branch: BranchCode; semester: string; college: string; mobile: string }): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = data.email.trim().toLowerCase();
    
    if (auth) {
      try {
        registeringRef.current = true;
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, data.pass);
        try {
          await updateProfile(cred.user, { displayName: data.name });
        } catch (e) {
          console.warn('Display name update skipped:', e);
        }
        const profile: UserProfile = {
          uid: cred.user.uid,
          email: cleanEmail,
          displayName: data.name || cleanEmail.split('@')[0],
          role: cleanEmail === ADMIN_EMAIL.toLowerCase() ? 'admin' : 'student',
          branch: data.branch,
          semester: data.semester,
          college: data.college,
          mobile: data.mobile,
          bookmarks: []
        };
        await saveUserProfileToFirestore(profile);
        setUser(profile);
        try { localStorage.setItem(LOCAL_USER_STATE, JSON.stringify(profile)); } catch {}
        return { success: true, message: 'Registration complete! Welcome to BTEUP Portal.' };
      } catch (fbErr: any) {
        console.warn("Firebase create user notice:", fbErr.code);
        return { success: false, message: friendlyAuthError(fbErr) };
      } finally {
        registeringRef.current = false;
      }
    }

    return { success: false, message: 'Registration service is unavailable right now. Please try again later.' };
  };

  const logout = async (): Promise<void> => {
    if (auth) {
      try {
        await signOut(auth);
      } catch (e) {
        console.error(e);
      }
    }
    setUser(null);
    localStorage.removeItem(LOCAL_USER_STATE);
  };

  const toggleBookmark = (resourceId: string) => {
    setBookmarks(prev => {
      let next: string[];
      if (prev.includes(resourceId)) {
        next = prev.filter(id => id !== resourceId);
      } else {
        next = [...prev, resourceId];
      }
      try { localStorage.setItem(LOCAL_BOOKMARKS_KEY, JSON.stringify(next)); } catch {}
      return next;
    });
  };

  const isAdmin = Boolean(user && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  return (
    <AuthContext.Provider value={{
      user,
      isAdmin,
      isLoading,
      login,
      register,
      logout,
      toggleBookmark,
      bookmarks
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
