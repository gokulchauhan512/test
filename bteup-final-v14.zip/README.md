# BTEUP Vault

Study resource portal for BTEUP diploma students (https://bteup.in).

## Run locally

1. Install dependencies: `npm install`
2. Start the dev server: `npm run dev`
3. Production build: `npm run build` (output in `dist`)

## Before publishing

- Publish `firestore.rules` in Firebase Console (Firestore Database, Rules).
- Delete any sample items in the Admin Panel (Manage tab) and upload real material.
- Legal pages live in `public/terms/` and `public/privacy/`.
